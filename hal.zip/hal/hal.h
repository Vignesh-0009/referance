#ifndef HALLIBRARY_H
#define HALLIBRARY_H
class HALLibrary {
public:
    virtual ~HALLibrary() {}
    virtual void write(float Value_x, float Values_y) = 0;
    virtual void read(float *value_x, float *value_y) = 0;
};

class FileBasedHAL : public HALLibrary {
public:
	FileBasedHAL();
	~FileBasedHAL();
    void write(float Value_x,float Values_y) override;  
    void read(float *value_x, float *value_y) override;

    //File based specific functions
    void writeToFile(float Value_x, float Value_y);
    void readFromFile(float *value_x, float *value_y);
};

struct Data {
    long mtype;
    float values[4];
};
class QueueBasedHAL : public HALLibrary {
public:
    QueueBasedHAL();
    ~QueueBasedHAL();
    void write(float Value_x,float Values_y) override;
    void read(float *value1, float *value2) override;

    //MessageQueue specific function 
};
#endif // HALLIBRARY_H
