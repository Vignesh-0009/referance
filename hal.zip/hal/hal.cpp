#include "hal.h"
#include <iostream>
#include <fstream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <sys/ipc.h>
#include <sys/msg.h>

// Global variables
using namespace std;
std::mutex fileMutex;
key_t key;
int msgid;
int writecount = 1;
int readcount = 1;


//Beginning of File based implementation
#ifdef FILE_BASED 
FileBasedHAL::FileBasedHAL() {}

FileBasedHAL::~FileBasedHAL() {}

// Function to write data to file
void FileBasedHAL::writeToFile(float Value_x, float Value_y) {
     // Check if the file is empty
    while (1) {
        ifstream inputFile("../../hal/data.txt");
        if (inputFile.peek() == std::ifstream::traits_type::eof()) {
            // If empty, open the file and write data
            ofstream filestream("../../hal/data.txt");
            if (filestream.is_open()) {
                filestream << "(" << Value_x << "," << Value_y << ")" << std::endl;
                filestream.close();
                std::cout << "File: hal.so:[ Data Count=" << writecount << "] Received  x=" << Value_x << " y=" << Value_y << std::endl;
                writecount++;
                break;
            } else {
                cout << "File opening is fail." << endl;
            }
        }
    }
}

// Function to read data from file
void FileBasedHAL::readFromFile(float *value_x, float *value_y) {
    // Lock the mutex to ensure exclusive file access
    std::lock_guard < std::mutex > lock(fileMutex);

    // Open and read from the file
    std::ifstream inFile("../../hal/data.txt");
    if (inFile.is_open()) {
        char leftParenthesis, comma, rightParenthesis;
        inFile >> leftParenthesis >> *value_x >> comma >> *value_y >> rightParenthesis;
        inFile.close();

        std::cout << "File: hal.so:[Data Count=" << readcount << "] sent x=" << *value_x << " y=" << *value_y << std::endl;
        readcount++;

        // Truncate the file to clear its content
        std::ofstream outFile("../../hal/data.txt", std::ios::trunc);
        if (!outFile) {
            std::cerr << "Failed to open the file for truncation." << std::endl;
        }
        outFile.close();
    } else {
        std::cerr << "Unable to open file for reading." << std::endl;
    }
}

void FileBasedHAL::write(float Value_x, float Value_y) {
    writeToFile(Value_x, Value_y);
    std::unique_lock < std::mutex > lock(fileMutex);
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
}

void FileBasedHAL::read(float *value_x, float *value_y) {
    std::this_thread::sleep_for(std::chrono::milliseconds(3));
    readFromFile(value_x, value_y);
}

extern "C" {
    FileBasedHAL arrayManager; //constrcutor for file based operations
    // Exposed function to write data
    void write(float Value_x, float Value_y) {
        arrayManager.write(Value_x, Value_y);
    }
    // Exposed function to read data
    void read(float *value_x, float *value_y) {
        arrayManager.read(value_x, value_y);
    }
}
#endif
//End of file based implementation


//Beginning of message queue based implementation
#ifdef MESSAGE_QUEUE_BASED
QueueBasedHAL::QueueBasedHAL() {
	fstream file;
	file.open("../../hal/message_queue_key",ios::out);
	file.close();
	key = ftok("../../hal/message_queue_key", 1);
    if (key == -1) {
        std::cerr << "ftok failed" << std::endl;
        return;
    }
    
    msgid = msgget(key, 0666 | IPC_CREAT);
    if (msgid == -1) {
        std::cerr << "msgget failed" << std::endl;
        return;
    }
}
QueueBasedHAL::~QueueBasedHAL() {}
 
void QueueBasedHAL::write(float Value_x,float Value_y) {
	
	//when write() function is called for the first time, if any message queue is already existing, that will be cleared to ensure seamless data transfer between generator and plotter.
	if(writecount == 1)
	{
		// Deleting the existing message queue
    	msgctl(msgid, IPC_RMID, NULL); 
    	//Object initialisation to create new message queue
    	QueueBasedHAL MessageQueue_new;
	}
	
    Data data;
    data.mtype = 1;
    data.values[0] = Value_x;
    data.values[1] = Value_y;
    
	// Send data to the message queue
    if (msgsnd(msgid, &data, sizeof(data.values), 0) == -1) {
        std::cerr << "msgsnd failed" << std::endl;
        return;
    }

    std::cout<<"Message queue: hal.so:[Data Count="<< writecount <<"] Received x="<<Value_x<<",y="<<Value_y<<std::endl;
    writecount++;
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
}

void QueueBasedHAL::read(float *value1, float *value2) {
    
    Data data;
    // Receive data from the message queue
    if (msgrcv(msgid, &data, sizeof(data.values), 0, 0) == -1) {
        std::cerr << "msgrcv failed" << std::endl;
        return;
}
    *value1 = data.values[0];
    *value2 = data.values[1];

    std::cout<<"Message queue: hal.so:[Data Count="<<readcount<<"] sent x="<<data.values[0]<<",y="<<data.values[1]<<std::endl;
    readcount++;
}

extern "C" {
    QueueBasedHAL MessageQueue;
    // Exposed function to write data to message queue
    void write(float Value_x,float Value_y) {
        MessageQueue.write(Value_x,Value_y);
    }
    // Exposed function to read data from message queue
    void read(float *value1, float *value2) {
        MessageQueue.read(value1,value2);
    }
}
#endif
//End of message queue based implementation

